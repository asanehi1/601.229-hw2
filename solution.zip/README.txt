Contributors: Alexis Sanehisa + Maudeline Deus

Maudeline Deus's contributions:
addPositive, fatalError, tokenType, consumeInt, consumeOp, stackPush, stackPop, evalOp

Alexis Sanehisa's contributions:
isSpace, isDigit, *skipws, valgrind issues, eval, edge cases 
