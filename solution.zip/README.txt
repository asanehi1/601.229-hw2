Contributors: Alexis Sanehisa + Maudeline Deus

Maudeline Deus's contributions:
tokenType, consumeInt, consumeOp, stackPush, stackPop, evalOp, edge case for consumeInt

Alexis Sanehisa's contributions:
isSpace, isDigit, *skipws, valgrind issues, eval, edge cases, addPositive, fatalError
