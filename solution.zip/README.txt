Contributors: Alexis Sanehisa + Maudeline Deus

Maudeline Deus's contributions M1:
tokenType, consumeInt, consumeOp, stackPush, stackPop, evalOp, edge case for consumeInt

Alexis Sanehisa's contributions M1:
isSpace, isDigit, *skipws, valgrind issues, eval, edge cases, addPositive, fatalError

Alexis Sanehisa's contributions M2:
everything (Maudeline is busy, she'll do more work for M3)

Maudeline Deus's contributions M3:
everything
